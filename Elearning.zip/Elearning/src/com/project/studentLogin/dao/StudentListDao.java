package com.project.studentLogin.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.project.crud.model.Course;
import com.project.studentregister.model.Student;

public class StudentListDao {
	
	private String url="jdbc:mysql://localhost:3306/project";
	private String password="root";
	private String user="root";
	
	private static final String select_all_student="select * from student;";
	
	protected Connection getConnection() {
		Connection conn=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		conn= DriverManager.getConnection(url,user,password);
	}catch (SQLException e) {
		e.printStackTrace();
	}catch (ClassNotFoundException e1) {
		e1.printStackTrace();
	}
	return conn;
	}
	
	public ArrayList<Student> selectAllStudent()
	{
		ArrayList<Student> student=new ArrayList<>();
		try(Connection conn=getConnection();
				PreparedStatement ps=conn.prepareStatement(select_all_student)){
			
			System.out.println(ps);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				int id=rs.getInt("id");
				String name=rs.getString("name");
				String phone_no=rs.getString("phone_no");
				String email=rs.getString("email");
				String address=rs.getString("address");
	
				student.add(new Student(id,name,phone_no,email,address));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return student;
	}
}
