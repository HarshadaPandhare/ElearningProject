package com.project.studentLogin.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.project.studentregister.model.Student;



public class StudentLoginDao {
public boolean validate(Student student) throws ClassNotFoundException{
		
		boolean status=false;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "root");
			
			PreparedStatement ps=conn.prepareStatement("select email, stud_password from student where email=? and stud_password=? ");
			ps.setString(1, student.getEmail());
			ps.setString(2, student.getPassword());
			
			System.out.println(ps);
			
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
}
