package com.project.studentLogin.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.crud.dao.CourseDao;
import com.project.crud.model.Course;
import com.project.studentLogin.dao.StudentListDao;
import com.project.studentregister.model.Student;

/**
 * Servlet implementation class StudentListServlet
 */
@WebServlet("/StudentListServlet")
public class StudentListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 private  StudentListDao sl_dao;
	
	    public void init()
	    {
	    	sl_dao=new StudentListDao();
	    }
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getServletPath();
		if (action.equalsIgnoreCase("list"))
		{
			listStudent(request,response);
		}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	private void listStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		ArrayList<Student> listStudent=sl_dao.selectAllStudent();
		request.setAttribute("listStudent", listStudent);
		RequestDispatcher dispatcher=request.getRequestDispatcher("StudentList.jsp");
		dispatcher.forward(request, response);
		
		
	}
	

}
