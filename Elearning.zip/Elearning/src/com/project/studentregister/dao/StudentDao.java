package com.project.studentregister.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.studentregister.model.Student;

public class StudentDao {
	public int registerStudent(Student student) throws ClassNotFoundException{
		String Insert_student="INSERT INTO student" + 
				" (stud_id, stud_name, phone_no, email, address,reg_date, stud_password) VALUES " +
				" (?,?,?,?,?,?,?);";
		
		int result=0;
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/Project", "root", "root");
			
			PreparedStatement ps=conn.prepareStatement(Insert_student);
			ps.setInt(1, student.getId());
			ps.setString(2, student.getName());
			ps.setString(3, student.getPhone_no());
			ps.setString(4, student.getEmail());
			ps.setString(5, student.getAddress());
			ps.setDate(6, new java.sql.Date(student.getReg_date().getTime()));
			ps.setString(7, student.getPassword());
			
			System.out.println(ps);
			
			result=ps.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}


}
