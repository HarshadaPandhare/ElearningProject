package com.project.studentregister.model;
import java.util.Date;


public class Student {
	
	private int id;
	private String name;
	private String phone_no;
	private String email;
	private String address;
	private Date reg_date;
	private String password;
	
	public Student() {
		super();
	}
	public Student(int id, String name, String phone_no, String email, String address) {
		super();
		this.id = id;
		this.name = name;
		this.phone_no = phone_no;
		this.email = email;
		this.address = address;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone_no() {
		return phone_no;
	}
	public void setPhone_no(String phone_no) {
		this.phone_no = phone_no;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
