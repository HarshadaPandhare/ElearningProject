package com.project.studentregister.controller;

import java.io.IOException;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.studentregister.dao.StudentDao;
import com.project.studentregister.model.Student;

/**
 * Servlet implementation class StudentServlet
 */
@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StudentDao s_dao= new StudentDao();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		RequestDispatcher dispatcher= request.getRequestDispatcher("/studentRegister.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Student student=new Student();
		
		String name=request.getParameter("name");
		String phone_no=request.getParameter("phone_no");
		String email=request.getParameter("email");
		String address=request.getParameter("address");
		Date reg_date=null;
		try {
			reg_date = new SimpleDateFormat("MM/dd/yyyy").parse(request.getParameter("reg_date"));
			//student.setReg_date(reg_date);
			
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String password=request.getParameter("password");
		
		student.setName(name);
		student.setPhone_no(phone_no);
		student.setEmail(email);
		student.setAddress(address);
		student.setReg_date(reg_date);
		student.setPassword(password);
		
		try {
			s_dao.registerStudent(student);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		RequestDispatcher dispatcher= request.getRequestDispatcher("/RegisterSuccess.jsp");
		dispatcher.forward(request, response);
		
		
	}

}
