package com.project.crud.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.project.crud.model.Course;


public class CourseDao {
	private static String url="jdbc:mysql://localhost:3306/project";
	private static String password="root";
	private static String user="root";
	
	private static final String Insert_course="INSERT INTO course" + 
			" (course_id, c_name, c_desp, c_fees) VALUES " +
			" (?,?,?,?);";
	
	private static final String select_course_by_id="select * from course where course_id=?;";
	private static final String select_all_course="select * from course;";
	private static final String delete_course="delete from course where course_id=?;";
	private static final String update_course="update course set c_name=?,c_desp=?,c_fees=? where course_id=?;";
	
	protected static Connection getConnection() {
		Connection conn=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		conn= DriverManager.getConnection(url,user,password);
	}catch (SQLException e) {
		e.printStackTrace();
	}catch (ClassNotFoundException e1) {
		e1.printStackTrace();
	}
	return conn;
	}
	
	public static int save(Course c)
	{
		int status=0;
		try
		{
			Connection conn=getConnection();
			PreparedStatement ps=conn.prepareStatement(Insert_course);
			ps.setInt(1, c.getId());
			ps.setString(2, c.getName());
			ps.setString(3, c.getDescription());
			ps.setDouble(4, c.getFee());
			status=ps.executeUpdate();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return status;
	}
	
	public void insertCourse(Course course) throws SQLException{
		try(Connection conn=getConnection();
				PreparedStatement ps=conn.prepareStatement(Insert_course)){
			ps.setInt(1, course.getId());
			ps.setString(2, course.getName());
			ps.setString(3, course.getDescription());
			ps.setDouble(4, course.getFee());
			ps.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public static int updateCourse(Course c) throws SQLException{
		int updated = 0;
		try(Connection conn=getConnection();
				PreparedStatement ps=conn.prepareStatement(update_course)){
			ps.setString(1, c.getName());
			ps.setString(2, c.getDescription());
			ps.setDouble(3, c.getFee());
			ps.setInt(4, c.getId());
			
			updated=ps.executeUpdate();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return updated;
	}
	
	public static Course selectCourse(int id)
	{
		Course c=null;
		try(Connection conn=getConnection();
				PreparedStatement ps=conn.prepareStatement(select_course_by_id)){
			
			ps.setInt(1, id);
			System.out.println(ps);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				c=new Course();
				c.setId(rs.getInt("course_id"));
				c.setName(rs.getString("c_name"));
				c.setDescription(rs.getString("c_desp"));
				c.setFee(rs.getDouble("c_fees"));
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return c;
	}
	
	
	public static ArrayList<Course> selectAllCourse()
	{
		ArrayList<Course> course=new ArrayList<>();
		try{
				
			Connection conn=getConnection();
			PreparedStatement ps=conn.prepareStatement(select_all_course);
			
			System.out.println(ps);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				Course c=new Course();
				c.setId(rs.getInt("course_id"));
				c.setName(rs.getString("c_name"));
				c.setDescription(rs.getString("c_desp"));
				c.setFee(rs.getDouble("c_fees"));
				/*int id=rs.getInt("id");
				String name=rs.getString("name");
				String description=rs.getString("description");
				double fee=rs.getDouble("fee");*/
				course.add(c);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return course;
	}
	
	
	public static int deleteCourse(Course c) throws SQLException{
		int deleted = 0;
		try(Connection conn=getConnection();
				PreparedStatement ps=conn.prepareStatement(delete_course)){
			ps.setInt(1, c.getId());
			
			deleted=ps.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return deleted;
	}
	
	private void printSQLException(SQLException ex)
	{
		for(Throwable e: ex)
		{
			if(e instanceof SQLException)
			{
				e.printStackTrace(System.err);
				System.err.println("SQL State:"+((SQLException) e).getSQLState());
				System.err.println("Error code:"+((SQLException) e).getErrorCode());
				System.out.println("Message:"+ e.getMessage());
				Throwable t=ex.getCause();
				
				while(t!=null)
				{
					System.out.println("Cause:"+t);
					t=t.getCause();
				}
			}
		}
	}

}
