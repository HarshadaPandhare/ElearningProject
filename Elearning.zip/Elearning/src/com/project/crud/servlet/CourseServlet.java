package com.project.crud.servlet;

import java.io.IOException;


import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.crud.dao.CourseDao;
import com.project.crud.model.Course;

/**
 * Servlet implementation class CourseServlet
 */
@WebServlet("/CourseServlet")
public class CourseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private  CourseDao c_dao;
  
    public void init()
    {
    	c_dao=new CourseDao();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action=request.getServletPath();
		try
		{
			switch(action)
			{
			case "/new":
				showNewForm(request,response);
				break;
			case "/insert":
				insertCourse(request,response);
				break;
			case "/delete":
				deleteCourse(request,response);
				break;
			case "/edit":
				showEditForm(request,response);
				break;
			case "/update":
				updateCourse(request,response);
				break;
			default:
				System.out.println(" In default");
				listCourse(request,response);
				break;
			}
		}
		catch(SQLException e)
		{
			throw new ServletException(e);
		}
		
	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher dispatcher=request.getRequestDispatcher("course_form.jsp");
		dispatcher.forward(request, response);
		
	}
	
	private void insertCourse(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		String description=request.getParameter("description");
		double fee=Double.parseDouble(request.getParameter("fee"));
		Course newCourse=new Course(name,description,fee);
		c_dao.insertCourse(newCourse);
		response.sendRedirect("list");
		
	}
	
	private void deleteCourse(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		//c_dao.deleteCourse(id);
		response.sendRedirect("list");
		
	}
	
	
	private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		Course existingCourse=c_dao.selectCourse(id);
		RequestDispatcher dispatcher=request.getRequestDispatcher("course_form.jsp");
		request.setAttribute("course", existingCourse);
		dispatcher.forward(request, response);
		
	}
	
	private void updateCourse(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String description=request.getParameter("description");
		double fee=Double.parseDouble(request.getParameter("fee"));
	
		Course newCourse=new Course(id,name,description,fee);
		//c_dao.updateCourse(newCourse);
		response.sendRedirect("list");
		
	}
	
	
	private void listCourse(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Inside listcourse");
		ArrayList<Course> listCourse=c_dao.selectAllCourse();
		request.setAttribute("listCourse", listCourse);
		RequestDispatcher dispatcher=request.getRequestDispatcher("a_course_list.jsp");
		dispatcher.forward(request, response);
		
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
