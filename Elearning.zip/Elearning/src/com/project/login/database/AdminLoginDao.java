package com.project.login.database;

import java.sql.DriverManager;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.project.registration.model.Admin;

import java.sql.Connection;

public class AdminLoginDao {
	
	public boolean validate(Admin admin) throws ClassNotFoundException{
		
		boolean status=false;
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/Project", "root", "root");
			
			PreparedStatement ps=conn.prepareStatement("select email,a_password from admin where email=? and a_password=? ");
			ps.setString(1, admin.getEmail());
			ps.setString(2, admin.getPassword());
			
			System.out.println(ps);
			
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return status;
}

}
