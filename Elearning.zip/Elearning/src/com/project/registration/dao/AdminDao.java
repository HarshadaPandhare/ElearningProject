package com.project.registration.dao;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Connection;
//import java.sql.ResultSet;
//import java.sql.Statement;
import com.project.registration.model.Admin;

public class AdminDao {
	
	public int registerAdmin(Admin admin) throws ClassNotFoundException{
		String Insert_admin="INSERT INTO admin" + 
				" (admin_id, a_name, email, a_password) VALUES " +
				" (?,?,?,?);";
		
		int result=0;
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		try {
			
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/Project", "root", "root");
			
			PreparedStatement ps=conn.prepareStatement(Insert_admin);
			ps.setInt(1, admin.getId());
			ps.setString(2, admin.getName());
			ps.setString(3, admin.getEmail());
			ps.setString(4, admin.getPassword());
			
			System.out.println(ps);
			
			result=ps.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

}
